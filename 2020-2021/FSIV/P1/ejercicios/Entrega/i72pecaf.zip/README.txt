To use this program you have to draw a rectangle by clicking the left bottom of your mouse.
Once you have your rectangle press ESC, then a new image will be desplayed. Close this
image and draw a new rectangle if you want. To close the program you must
kill the process in terminal where the program was launched.
