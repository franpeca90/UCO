El ejecutable se encuentra dentro de la carpeta "build"

Para compilar:
    - mkdir build
    - cd build
    - cmake ..
    - make