How to compile
==============
    - mkdir build
    - cd build
    - cmake ..
    - make


Examepl about how to run the program
======================
    - ./calibration -w=6 -h=4 -pt=chessboard -o=../instrinsics.yml -op -oe -V ../video_camera.mp4


How to use
==========
