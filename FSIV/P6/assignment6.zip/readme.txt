How to compile
==============
    - mkdir build
    - cd build
    - cmake ..
    - make


How to run the program
======================
    - ./assignment6 [image path]


How to use
==========
This program applyies the box filter and the median filter for black and white images and for color images.
User has to choose between these two types and introduce the size of the kernel, it must be odd.
