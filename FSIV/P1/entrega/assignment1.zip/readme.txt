How to compile
==============
    - mkdir build
    - cd build
    - cmake ..
    - make


How to run the program
======================
    - ./assignment1 [image path]


How to use
==========
To run the program correctly, you need to write the path of the picture you want to highlight
You can create the rectangle by clicking and draggin. 
Once you have your rectangle created you can press ENTER and see a new window with your rectangle's area in colour.
You can go to the original window and create a new rectangle, pressing ENTER again and creating a new window with a new area in color.
The program will end if the user press ESC key.