How to compile
==============
    - mkdir build
    - cd build
    - cmake ..
    - make


How to run the program
======================
    - ./assignment2 [image path]


How to use
==========
The program will create a new image with balance black and white colors.
The program will finish when any key is pressed.