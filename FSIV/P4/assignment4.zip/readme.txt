How to compile
==============
    - mkdir build
    - cd build
    - cmake ..
    - make


How to run the program
======================
    - ./assignment4 [image path]


How to use
==========
Users can introduce an image and the program will show the magnitude of the image.

