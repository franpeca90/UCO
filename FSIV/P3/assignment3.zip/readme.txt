How to compile
==============
    - mkdir build
    - cd build
    - cmake ..
    - make


How to run the program
======================
    - ./assignment3 [image path]


How to use
==========
User introduce by keybord an odd number to specify the size of the kernel. After this
the program show the original image and a new image with the kernel applied in most part of the image.
