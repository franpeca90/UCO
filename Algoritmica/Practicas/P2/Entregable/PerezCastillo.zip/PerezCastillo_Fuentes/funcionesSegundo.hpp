#include "serietemporal.hpp"

#include <iostream>
#include <fstream>

void metodoSegundo();
void recursivaSegundo(SerieTemporal *serie, int puntoIzquierda, int puntoDerecha, double eMax);