#include "serietemporal.hpp"

#include <iostream>
#include <fstream>

void metodoPrimero();
void recursivaPrimero(SerieTemporal *serie, int puntoIzquierda, int puntoDerecha, double eMax);